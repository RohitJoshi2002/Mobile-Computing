# SimpleEMICalculator
Simple android EMI (Estimated Monthly Installment) application to calculate Loan EMI. This is a basic app with simple xml and java code.
